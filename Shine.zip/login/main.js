
export default {
	name: '',
	data () {
		return {
			msg: 'hello world'
		}
	}
}