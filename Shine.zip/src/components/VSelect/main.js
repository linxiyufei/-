
export default {
	name: 'v-select',
	data () {
		return {
			
		}
	}
}