
<template>
	<div>
		<VMain :subnav="subNav" nav-title="考核云图"></VMain>
	</div>
</template>

<style lang="scss" scoped>
	@import './layout.scss'
</style>

<script>
	import main from './main.js'
	export default main
</script>