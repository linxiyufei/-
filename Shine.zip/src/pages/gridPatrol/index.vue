
<template>
	<div>
		<VMain :subnav="subNav" has-child="true" nav-title="网格巡防"></VMain>
	</div>
</template>

<style lang="scss" scoped>
	@import './layout.scss'
</style>

<script>
	import main from './main.js'
	export default main
</script>