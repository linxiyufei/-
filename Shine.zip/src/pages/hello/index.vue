<template>
	<section>
		<h1>{{ msg }}</h1>
	</section>
</template>

<style lang="scss" scoped>
	@import './layout.scss'
</style>

<script>
	import main from './main.js'
	export default main
</script>