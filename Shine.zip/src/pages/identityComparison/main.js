
export default {
	name: '',
	data () {
		return {
			msg: 'hello 身份比对'
		}
	}
}