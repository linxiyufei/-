
<template>
	<div>
		<VMain :subnav="subNav" nav-title="图上作战"></VMain>
	</div>
</template>

<style lang="scss" scoped>
	@import './layout.scss'
</style>

<script>
	import main from './main.js'
	export default main
</script>