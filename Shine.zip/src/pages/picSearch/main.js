
export default {
	name: '',
	data () {
		return {
			model1: '',
			model2: '',
			model3: '',
			gridList1: [],
			gridList2: [],
			gridList3: []
		}
	}
}