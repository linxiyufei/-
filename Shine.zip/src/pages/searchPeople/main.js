
export default {
	name: '',
	data () {
		return {
			msg: '选择特征进行搜索',
			formItem: {
                radio: 'male',
                selectAge:'',
                selectHeight:'',
                selectClothing:'',
                selectTraffic:''
            }
		}
	}
}