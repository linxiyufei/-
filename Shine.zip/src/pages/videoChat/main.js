
export default {
	name: '',
	data () {
		return {
			msg: '视频通话'
		}
	}
}